setwd("C:\\Users\\IT24101325\\Desktop\\IT24101325")
getwd()
branch_data <- read.table("Exercise.txt", header=TRUE,sep=",")
fix(branch_data)
str(branch_data)
boxplot(branch_data$Sales_X1, main="Boxplot of Sales", ylab = "sales")
summary(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)
get.outliers<- function(x){
  q1 <- quantile(x,0.25)
  q2 <- quantile(x,0.75)
  iqr <- q3 - q1
  
  lb<- q1 - 1.5 * iqr
  ub<- q3 + 1.5 * iqr
  
  outliers <- x[x < lb | x > ub]
  return(outliers)
}
outliers_in_years<- find_outliers(branch_data$Years_X3)
outliers_in_years